# Spor Analiz Programi: Web Veri Tabanlı Spor Tahmin Sistemi + Gelişmiş Özellikler + Gerçek Skor ve Form Etkenli Yapay Zeka + Gelişmiş Filtreler + Giriş Sistemi

# GEREKLİ KÜTÜPHANELER
import pandas as pd
from datetime import datetime
import sqlite3
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from flask import Flask, render_template_string, request, redirect, url_for, session
import random

# VERİTABANI AYARI
DB_NAME = "spor_analiz.db"
...
# ANA FONKSİYON
if __name__ == "__main__":
    veritabani_olustur()
    kullanici_kaydet("demo", "1234")
    df_sanal = rastgele_mac_uret()
    if not df_sanal.empty:
        veritabaniya_kaydet(df_sanal)
    app.run(debug=True)
